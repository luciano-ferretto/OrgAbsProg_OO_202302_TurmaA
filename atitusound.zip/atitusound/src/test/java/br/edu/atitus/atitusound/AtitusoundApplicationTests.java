package br.edu.atitus.atitusound;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtitusoundApplicationTests {

	@Test
	void contextLoads() {
	}

}
